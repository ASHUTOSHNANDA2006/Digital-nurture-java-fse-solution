public class WordDocumentFactory {
    
}
