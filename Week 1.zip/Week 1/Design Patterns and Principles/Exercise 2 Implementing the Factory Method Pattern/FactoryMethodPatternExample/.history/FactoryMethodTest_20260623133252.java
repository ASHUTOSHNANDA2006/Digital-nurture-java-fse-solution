public class FactoryMethodTest {
    
}
