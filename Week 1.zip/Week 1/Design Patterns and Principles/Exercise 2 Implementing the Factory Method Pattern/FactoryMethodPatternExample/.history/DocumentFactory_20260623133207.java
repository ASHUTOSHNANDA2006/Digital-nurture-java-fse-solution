public class DocumentFactory {
    
}
